# 📰 Fake News Detector

This is a simple Fake News Detector web app built with **Streamlit**.

## Files
- `app.py`: The main Streamlit application.
- `requirements.txt`: Dependencies required for running the app.
- `model.pkl`: Trained ML model (Logistic Regression, Naive Bayes, etc.).
- `vectorizer.pkl`: TF-IDF vectorizer used for feature extraction.

## How to run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deployment (Streamlit Cloud)
1. Push these files (`app.py`, `requirements.txt`, `model.pkl`, `vectorizer.pkl`) to a GitHub repository.
2. Go to [Streamlit Cloud](https://share.streamlit.io/).
3. Connect your GitHub and deploy the app.
4. Done! 🎉