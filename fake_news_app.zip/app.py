import streamlit as st
import pickle
import re

# Load saved model and vectorizer
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

# Text cleaning
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return text

st.title("📰 Fake News Detector")

user_input = st.text_area("Paste a news headline or article:")

if st.button("Predict"):
    if user_input.strip() != "":
        cleaned = clean_text(user_input)
        X = vectorizer.transform([cleaned])
        prediction = model.predict(X)[0]
        st.success(f"Prediction: **{prediction}**")
    else:
        st.warning("Please enter some text!")